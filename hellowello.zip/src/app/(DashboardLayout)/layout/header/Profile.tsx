import React, { useState } from "react";
import Link from "next/link";
import {
  Avatar,
  Box,
  Menu,
  Button,
  IconButton,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material";
import { IconListCheck, IconMail, IconUser } from "@tabler/icons-react";
import createAxiosInstance from "@/app/axiosInstance";
import Cookies from "js-cookie";
import { useRouter } from "next/navigation";
import ProfileName from "./ProfileName";
import LoadingButton from "@mui/lab/LoadingButton";
import useMediaQuery from "@mui/material/useMediaQuery";

const Profile = () => {
  const [anchorEl2, setAnchorEl2] = useState(null);
  const [loader, setLoader] = useState<boolean>(false);
  const handleClick2 = (event: any) => {
    setAnchorEl2(event.currentTarget);
  };
  const handleClose2 = () => {
    setAnchorEl2(null);
  };

  const router = useRouter();

  const handleLogout = async () => {
    try {
      setLoader(true);
      const axiosIntance = createAxiosInstance();
      const response = await axiosIntance.post(`user/logout`);
      localStorage.clear();
      const cookies = Cookies.get();
      for (const cookie in cookies) {
        Cookies.remove(cookie);
      }
      router.push("/authentication/login");
    } catch {
      console.log("error occured");
    } finally {
      setLoader(false);
    }
  };

  const isMobile = useMediaQuery("(max-width: 767px)");
  const isSmallMobiles = useMediaQuery("(max-width: 575px)");
  const isBiggerMobiles = useMediaQuery(
    "(min-width: 576px) and (max-width: 767px)"
  );

  return (
    <Box
      sx={{
        ...(isMobile && {
          width: "20%",
        }),
      }}
    >
      <IconButton
        size="large"
        aria-label="show 11 new notifications"
        color="inherit"
        aria-controls="msgs-menu"
        aria-haspopup="true"
        sx={{
          ...(typeof anchorEl2 === "object" && {
            color: "primary.main",
          }),
        }}
        onClick={handleClick2}
      >
        <Avatar
          src="/images/profile/user-1.jpg"
          alt="image"
          sx={{
            width: 35,
            height: 35,
          }}
        />
      </IconButton>
      {/* ------------------------------------------- */}
      {/* Message Dropdown */}
      {/* ------------------------------------------- */}
      <Menu
        id="msgs-menu"
        anchorEl={anchorEl2}
        keepMounted
        open={Boolean(anchorEl2)}
        onClose={handleClose2}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        sx={{
          "& .MuiMenu-paper": {
            width: "200px",
          },
        }}
      >
        <Box sx={{ my: 1.5, px: 2.5 }}>
          {/* <Typography variant="subtitle2" noWrap>
            {basicDetails?.firstName} {basicDetails?.lastName}
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }} noWrap>
            {basicDetails?.email}
          </Typography> */}
          <ProfileName />
        </Box>

        <Divider sx={{ borderStyle: "dashed" }} />
        <MenuItem>
          <ListItemIcon>
            <IconUser width={20} />
          </ListItemIcon>
          <ListItemText 
          onClick={()=> router.push('/profile')}
          >
            
              My Profile
           
          </ListItemText>
        </MenuItem>
        <Box mt={1} py={1} px={2}>
          <Box>
            <LoadingButton
              variant="outlined"
              color="primary"
              fullWidth
              onClick={handleLogout}
              loading={loader}
            >
              Logout
            </LoadingButton>
          </Box>
        </Box>
      </Menu>
    </Box>
  );
};

export default Profile;
