import React, { useEffect, useState } from 'react';
import { Typography } from "@mui/material";
import { useAppselector } from "@/redux/store";
import { useDispatch } from 'react-redux'
import { getUserDetailsAsync } from '@/redux/features/userSlice';

function ProfileName() {
    const [userDetails, setUserDetails] = useState()


    const dispatch = useDispatch();
    // const fetchUser = async () => {
    //     try {
    //         // Add parentheses to dispatch
    //         const userDetails: any = await dispatch(getUserDetailsAsync());
    //         setUserDetails(userDetails.data);
    //     } catch (error) {
    //         console.log(error);
    //     }
    // };

    useEffect(() => {
        dispatch(getUserDetailsAsync());
    }, [dispatch]);

    const {firstName,lastName} = useAppselector((state) => state.user.value);


    return (
        <div>
            <Typography
                sx={{
                    marginLeft: "2px",
                    fontFamily: "Poppins",
                    fontSize: 20,
                    fontWeight: 500,

                    letterSpacing: "0em",
                    textAlign: "left",
                    color: "#2B376E",
                    marginRight: "-20px",
                }}
            >
                {firstName} {lastName}
            </Typography>
        </div>
    )
}

export default ProfileName;