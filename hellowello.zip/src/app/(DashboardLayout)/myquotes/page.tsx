"use client"
import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { Box, Card, FormControl, Grid, Paper, TextField, Typography } from '@mui/material';
import PlaceOutlinedIcon from '@mui/icons-material/PlaceOutlined';
import MenuItem from '@mui/material/MenuItem';
import Slider from '@mui/material/Slider';
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";



export default function AlertDialog() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

 

  return (
    <React.Fragment>
      <Button variant="outlined" onClick={handleClickOpen}>
        Open alert dialog
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        maxWidth="md"
        fullWidth={true}
        sx={{
         "& .MuiDialog-paper": {
            borderRadius: "20px",
          },
        }}
      >

        <DialogContent>
          <Grid container spacing={2} >

            <Grid item xs={12} >
              <Box display={'flex'} flexDirection={'row'} justifyContent={'space-between'}
                sx={{ maxHeight: "100%", }}>
                <Typography sx={{
                  fontSize: "22px", color: "#2B305C",
                  p: "8px", fontWeight: "600"
                }}>Create Quote</Typography>
                <Button onClick={handleClose} size="small" sx={{ minWidth: "0px" }}>
                  <CloseRoundedIcon
                    sx={{
                      marginLeft: "auto",
                      width: "20px",
                      height: "20px",
                      borderRadius: "50%",
                      border: "1px solid #2B305C",
                      color: "##2B305C",
                      minWidth: "0px",

                    }}
                  />
                </Button>
              </Box>

            </Grid>




            <Grid item xs={6} >

              <Card sx={{ backgroundColor: "#FFFFFF", padding: "19px", borderRadius: "20px" }}>
                <Box display="flex" flexDirection="column">
                  <Typography>
                    ₹ 50/unit
                  </Typography>
                  <Typography>Minimum Order: 40 unit</Typography>
                  <Typography>MUG</Typography>
                  <Box sx={{ display: "flex",  }}>
                    <PlaceOutlinedIcon sx={{ width: "14", height: "14", color: "#BFC8D6", }} />
                    <Typography sx={{
                      fontFamily: "Poppins",
                      fontSize: "12px",
                      fontWeight: 500,

                      letterSpacing: "0em",
                      textAlign: "left",
                      color: "#333542",

                    }}>Up, Ghaziabad</Typography>
                  </Box>
                </Box>
              </Card>
              <Card sx={{
                padding: "19px",
                backgroundColor: "#FFFFFF",
                mt: "16.5px",
                borderRadius: "20px"
              }}>
                <Typography sx={{
                  fontFamily: "Poppins",
                  fontSize: "14px",
                  fontWeight: 500,
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#000000",

                }}>ID:RQ1699357815PL</Typography>
                <Typography sx={{
                  fontFamily: "Poppins",
                  fontSize: "14px",
                  fontWeight: 700,
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#2B376E",

                }}>RFQ DETAILS</Typography>
                <Typography>NAME</Typography>

                <Box sx={{ display: "flex", flexDirection: "row", justifyContent: "space-between", mt: "10px" }}>
                  <Grid item xs={6}>
                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: "12px",
                        fontWeight: 400,

                        letterSpacing: "0em",
                        textAlign: "left",
                        color: "#333542",
                        marginBottom: "1px",

                      }}
                    >
                      EXPECTED PRICE
                      {" "}
                    </Typography>


                    <Typography sx={{
                      fontFamily: "Poppins",
                      fontSize: "12px",
                      fontWeight: 500,
                      letterSpacing: "0em",
                      textAlign: "left",
                      color: "#000000",
                      marginBottom: "1px",
                    }}>
                      {" "}
                      ₹ 10/piece

                    </Typography>
                  </Grid>
                  <Grid item xs={6} >

                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: "12px",
                        fontWeight: 400,

                        letterSpacing: "0em",
                        textAlign: "left",
                        color: "#333542",
                        marginBottom: "1px",

                      }}
                    >
                      REQUIRED QUANTITY
                      {" "}
                    </Typography>


                    <Typography sx={{
                      fontFamily: "Poppins",
                      fontSize: "12px",
                      fontWeight: 500,

                      letterSpacing: "0em",
                      textAlign: "left",
                      color: "#333542",

                      marginBottom: "1px"
                    }}>
                      {" "}
                      1 piece

                    </Typography>
                  </Grid>
                </Box>


              </Card>
              <Card sx={{
                padding: "19px",
                backgroundColor: "#FFFFFF",
                mt: "16.5px",
                borderRadius: "20px"
              }}>
                <Typography sx={{
                  fontFamily: "Poppins",
                  fontSize: "16.5px",
                  fontWeight: 600,
                  letterSpacing: "0em",
                  textAlign: "left",
                  color: "#000000",
                }}>DELIVERY ADDRESS</Typography>
                <Grid item xs={6}>
                  <Typography sx={{
                    fontFamily: "Poppins",
                    fontSize: "12px",
                    fontWeight: 500,
                    letterSpacing: "0em",
                    textAlign: "left",
                    color: "#333542",
                
                  }}>Room No.4, Poddar Court, Gate No.2, 7th Floor, 18, Rabindra Sarani,Kolkata – 700001</Typography>

                </Grid></Card>



            </Grid>
            <Grid item xs={6} >
              <Paper elevation={1} sx={{
                padding: "10px", backgroundColor: "#FFFFFF", borderRadius: "20px",
                maxHeight: "100%", display: 'flex', flexDirection: "column", justifyContent: "center", alignItems: "center"
              }}>
                <Box
                  display={"flex"}
                  justifyContent="start"
                  alignItems="start"
                >
                  <FormControl >
                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#333542",

                      }}
                    >
                      Quantity
                    </Typography>
                    <TextField
                      name="firstName"
                      placeholder="Enter Quantity"
                      InputProps={{
                        sx: {
                          borderRadius: 25,
                          width: 330,
                          height: 30,
                          backgroundColor: '#FFFFFF',
                          color: "#64758B",

                          fontFamily: "Poppins",
                          fontSize: "14px",
                          fontWeight: 400,
                        },
                      }}

                    />
                  </FormControl>
                </Box>
                <Box
                  display={"flex"}
                  justifyContent="start"
                  alignItems="start"
                >
                  <FormControl >
                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#333542",
                        my: "5px",
                      }}
                    >
                      Unit of Measurement
                    </Typography>
                    <TextField
                      select

                      // label="Choose Unit of Measurement"
                      variant="outlined"
                      InputProps={{
                        sx: {
                          borderRadius: 25,
                          width: 330,
                          height: 30,
                          backgroundColor: '#FFFFFF',
                          color: "#64758B",
                          fontFamily: "Poppins",
                          fontSize: "14px",
                          fontWeight: 400,
                        },
                      }}
                    >

                      <MenuItem value="option1">Option 1</MenuItem>
                      <MenuItem value="option2">Option 2</MenuItem>
                      <MenuItem value="option3">Option 3</MenuItem>

                    </TextField>
                  </FormControl>
                </Box>
                <Box
                  display={"flex"}
                  justifyContent="start"
                  alignItems="start"
                >
                  <FormControl >
                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#333542",
                        my: "10px",
                      }}
                    >
                      Unit Price
                    </Typography>
                    <TextField
                      name="firstName"
                      placeholder="Enter Unit Price"
                      InputProps={{
                        sx: {
                          borderRadius: 25,
                          width: 330,
                          height: 30,
                          backgroundColor: '#FFFFFF',
                          color: "#64758B",

                          fontFamily: "Poppins",
                          fontSize: "14px",
                          fontWeight: 400,
                        },
                      }}

                    />
                  </FormControl>
                </Box>
                <Box
                  display={"flex"}
                  flexDirection={'column'}
                  justifyContent="start"
                  alignItems="start"
                >
                  <Typography sx={{ mt: "5px" }}>Delivery Date</Typography>
                  <Slider
                    size="small"
                    defaultValue={20}
                    aria-label="Small"
                    valueLabelDisplay="auto"
                    step={1}
                    min={0}
                    max={20}
                    sx={{ width: 330 }}
                  />
                </Box>

                <Box
                  display={"flex"}
                  justifyContent="start"
                  alignItems="start"
                >
                  <FormControl >
                    <Typography
                      sx={{
                        fontFamily: "Poppins",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#333542",
                        my: "5px",
                      }}
                    >
                      Contact Person
                    </Typography>
                    <TextField
                      select

                      // label="Choose Unit of Measurement"
                      variant="outlined"
                      InputProps={{
                        sx: {
                          borderRadius: 25,
                          width: 330,
                          height: 30,
                          backgroundColor: '#FFFFFF',
                          color: "#64758B",
                          fontFamily: "Poppins",
                          fontSize: "14px",
                          fontWeight: 400,
                        },
                      }}
                    >

                      <MenuItem value="option1">Mayank</MenuItem>
                      <MenuItem value="option2">Suresh</MenuItem>
                      <MenuItem value="option3">Pawan</MenuItem>
                      <MenuItem value="option4">Sathish</MenuItem>
                    </TextField>
                  </FormControl>
                </Box>
                <FormControl >
                  <Typography
                    sx={{
                      fontFamily: "Poppins",
                      fontSize: 14,
                      fontWeight: 500,
                      color: "#333542",
                      my: "5px",
                    }}
                  >
                    Additional Note
                  </Typography>
                  <TextField
                    InputProps={{
                      sx: {
                        width: 330,
                        height: 45,
                        color: "#64758B",
                        fontFamily: "Poppins",
                        fontSize: "14px",
                        fontWeight: 400,
                        display: "flex",
                        alignItems: "flex-start",
                        justifyContent: "flex-start",
                      },
                    }}
                    name="description"
                    placeholder="Additional Note"
                  />


                </FormControl>

                <Button onClick={handleClose} variant='contained' sx={{
                  width: "330px",
                  height: "30px",
                  padding: "0px, 16px, 0px, 16px",
                  borderRadius: "25px",
                  gap: "16px",
                  backgroundColor: "#2B376E",
                  fontFamily: "Poppins",
                  fontSize: "14px",
                  fontWeight: 600,
                  letterSpacing: "0px",
                  textAlign: "center",
                  color: "#FFFFFF",
                  mt: "9px"
                }}>SUBMIT QUOTE</Button>
              </Paper>
            </Grid>

          </Grid>

        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
}
