"use client";
import PageContainer from "@/app/(DashboardLayout)/components/container/PageContainer";
// components
import * as React from "react";
import styled from "@emotion/styled";
import { Paper, Theme, ThemeProvider, createTheme } from "@mui/material";
import { Box, CssBaseline, Grid, Typography, Button } from "@mui/material";
import Carousel from "react-material-ui-carousel";
import Divider from "@mui/material/Divider";
import { useState, useEffect } from "react";
import object from "../../img/OBJECTS.jpg";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import StarBorderPurple500OutlinedIcon from "@mui/icons-material/StarBorderPurple500Outlined";
import QuestionAnswerOutlinedIcon from "@mui/icons-material/QuestionAnswerOutlined";
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import Link from "next/link";
import Image from "next/image";
import createAxiosInstance from "../axiosInstance";
import { CircularProgress } from "@mui/material";
import { useRouter } from "next/navigation";
import { usePathname } from "next/navigation";
import VerticalShadesClosedOutlinedIcon from "@mui/icons-material/VerticalShadesClosedOutlined";
import toast from "react-hot-toast";
import { catalogType, buyLeadsType, marketplaceType } from "@/types/types";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { CardActionArea } from "@mui/material";
import PlaceOutlinedIcon from "@mui/icons-material/PlaceOutlined";
// import { logIn } from "@/redux/features/authSlice";
// import { useDispatch } from 'react-redux'
// import { AppDispatch } from "@/redux/store";
import marketPlaceImage from "../../img/marketplace2333.png";
import businessListImage from "../../img/businessLIsting.png";
import { useAppselector } from "@/redux/store";
import useMediaQuery from "@mui/material/useMediaQuery";

const Dashboard = () => {
  const [viewAllCat, setViewAllCat] = useState(false);
  const [marketPlace, setMarketPlace] = useState<marketplaceType[]>([]);
  const [loadingMarketPlace, setLoadingMarketPlace] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [buyleads, setBuyLeads] = useState<buyLeadsType[]>([]);
  const [loading, setLoading] = useState(true);
  const [pageNumber, setPageNumber] = useState(1);
  const [count, setCount] = useState(20);
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState(1);
  const [catalogueData, setCatalogueData] = useState<catalogType[]>([]);
  const { defaultBusinessId } = useAppselector((state) => state?.user.value);

  let BusinessId = defaultBusinessId;

  const matches = useMediaQuery("(min-width:600px)");

  const pathName = usePathname();
  const router = useRouter();
  // const dispatch = useDispatch<AppDispatch>()
  function formatCreatedAt(createdAt: string) {
    const date = new Date(createdAt);
    const formattedDate = `${date.getDate().toString().padStart(2, "0")}-${(
      date.getMonth() + 1
    )
      .toString()
      .padStart(2, "0")}-${date.getFullYear()}`;
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? "PM" : "AM";
    const formattedTime = `${(hours % 12).toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")} ${ampm}`;
    return `${formattedDate} ${formattedTime}`;
  }

  const handleQuery = (id: string) => {
    router.push(`/marketplace?catalogueId=${id}`);
  };

  async function fetchMarketPlace() {
    try {
      setLoadingMarketPlace(true);
      const axiosInstance = createAxiosInstance();

      const response = await axiosInstance.get(
        `businessListing/list?pageNumber=1&count=4&sortBy=name&sortOrder=1`
      );

      const newData = await response.data.data;

      setMarketPlace(newData);
      setLoadingMarketPlace(false);
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "An error occurred");
    }
  }

  const fetchBuyLeads = async () => {
    try {
      const axiosInstance = createAxiosInstance();

      const response = await axiosInstance.get(
        `rfq/buy_leads/list?pageNumber=1&count=3&businessId=${BusinessId}&sortBy=Newest`
      );

      const newData = await response.data.data;
      setBuyLeads(newData);
      setLoading(false);
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "An error occurred");

      setLoading(false);
    }
  };

  const fetchCatalogue = async () => {
    try {
      const axiosInstance = createAxiosInstance();

      const response = await axiosInstance.get(
        `/productCatalog/catalogs_list?seeAll=true`
      );

      const newData = response.data.data;

      setCatalogueData(newData);

      setLoading(false);
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "An error occurred");
      setLoading(false);
    }
  };

  const fetchBasic = async () => {
    try {
      const axiosInstance = createAxiosInstance();
      const response = await axiosInstance.get(`user`);

      const businessId = response.data.data.defaultBusinessId;

      const userData = response.data.data;

      // Store businessId in local storage
      
      localStorage.setItem("businessId", businessId);
      localStorage.setItem("user", JSON.stringify(response.data.data));
      console.log(userData.isNewUser);
    } catch (error: any) {
      console.error(error);
    }
  };

  const isMobile = useMediaQuery("(max-width: 767px)");
  const isSmallMobile = useMediaQuery("(max-width: 575px)");
  const isBigMobile = useMediaQuery(
    "(min-width: 576px) and (max-width: 767px)"
  );
  const isBigSmallMobile = useMediaQuery(
    "(min-width: 576px) and (max-width: 600px)"
  );
  const isTablets = useMediaQuery("(min-width: 768px) and (max-width: 1024px)");
  const isSmallTabletss = useMediaQuery(
    "(min-width: 991px) and (max-width: 1024px)"
  );
  const isBiggerDevice = useMediaQuery(
    "(min-width: 1366px) and (max-width: 5000px)"
  );
  const isSmallBiggerDevice = useMediaQuery(
    "(min-width: 1300px) and (max-width: 1365px)"
  );
  const isSmallBiggersDevice = useMediaQuery(
    "(min-width: 1366px) and (max-width: 1462px)"
  );

  useEffect(() => {
    fetchBasic();
    fetchCatalogue();
    fetchBuyLeads();
    fetchMarketPlace();
    //eslint-disable-next-line
  }, []);
  return (
    <PageContainer title="Dashboard" description="this is Dashboard">
      <Box>
        <Grid
          container
          spacing={2}
          sx={{
            paddingX: "0px",
            marginLeft: "0px",
            paddingTop: "20px",
            width: "100% !important",
          }}
        >
          <CssBaseline />

          {/* {matches == true ? (
            ""
          ) : (
            
          )} */}

          <Card
            sx={{
              padding: "30px",
              boxShadow: "none",
              borderRadius: "13px",
              ...(isMobile && {
                display: "block !important",
              }),
            }}
          >
            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  ...(isMobile && {
                    flexDirection: "column",
                  }),
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    width: "76.3%",
                    justifyContent: "space-between",
                    ...(isMobile && {
                      flexDirection: "column",
                      width: "100%",
                    }),
                  }}
                >
                  <Card
                    sx={{
                      display: "flex",
                      background: "#7B8FD9",
                      width: "49%",
                      padding: "10px 8px 4px",
                      borderRadius: "10px",
                      ...(isMobile && {
                        width: "100%",
                        marginBottom: "15px",
                      }),
                      ...(isSmallMobile && {
                        flexDirection: "column-reverse",
                      }),
                      ...(isTablets && {
                        flexDirection: "column-reverse",
                      }),
                    }}
                  >
                    <CardContent>
                      <Typography
                        sx={{
                          fontFamily: "Poppins",
                          fontSize: 20,
                          fontWeight: 600,

                          letterSpacing: "0.5px",
                          textAlign: "left",
                          color: "#FFFFFF",
                          marginBottom: "10px",
                        }}
                      >
                        Marketplace
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Poppins",
                          fontSize: 14,
                          fontWeight: 600,

                          letterSpacing: "0.5px",
                          textAlign: "left",
                          color: "#FFFFFF",
                          ...(isMobile && {
                            fontSize: "14px",
                          }),
                        }}
                      >
                        Explore a diverse marketplace that caters to your every
                        need, offering quality products and unmatched
                        experiences
                      </Typography>

                      <Button
                        variant="contained"
                        sx={{
                          borderRadius: "30px",
                          marginTop: "10px",
                          backgroundColor: "#2B376E",
                          textTransform: "none",
                        }}
                      >
                        View More
                      </Button>
                    </CardContent>
                    <CardMedia>
                      <Image
                        alt="Object"
                        src={marketPlaceImage}
                        width={186}
                        height={201}
                        style={{
                          objectFit: "cover",
                          border: "1px solid #ddd",
                          borderRadius: "7px",
                          padding: "3px",
                          ...(isSmallMobile && {
                            width: "100%",
                            height: "201px",
                          }),
                          ...(isTablets && {
                            width: "100%",
                            height: "201px",
                          }),
                          ...(isBiggerDevice && {
                            width: "170px",
                            height: "170px",
                          }),
                        }}
                      />
                    </CardMedia>
                  </Card>
                  <Card
                    sx={{
                      display: "flex",
                      background: "#7B8FD9",
                      width: "49%",
                      padding: "10px 8px 4px",
                      borderRadius: "10px",
                      ...(isMobile && {
                        width: "100%",
                        marginBottom: "15px",
                      }),
                      ...(isSmallMobile && {
                        flexDirection: "column-reverse",
                      }),
                      ...(isTablets && {
                        flexDirection: "column-reverse",
                      }),
                    }}
                  >
                    <CardContent>
                      <Typography
                        sx={{
                          fontFamily: "Poppins",
                          fontSize: 20,
                          fontWeight: 600,

                          letterSpacing: "0.5px",
                          textAlign: "left",
                          color: "#FFFFFF",
                          marginBottom: "10px",
                        }}
                      >
                        Business Lists
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Poppins",
                          fontSize: 14,
                          fontWeight: 600,

                          letterSpacing: "0.5px",
                          textAlign: "left",
                          color: "#FFFFFF",
                          ...(isMobile && {
                            fontSize: "14px",
                          }),
                        }}
                      >
                         Quality, convenience, and customer care  Explore our
                        [products/services] and discover a new standard of
                        excellence. &quot;
                        
                      </Typography>

                      <Button
                        variant="contained"
                        sx={{
                          borderRadius: "30px",
                          marginTop: "10px",
                          backgroundColor: "#2B376E",
                          textTransform: "none",
                        }}
                      >
                        View More
                      </Button>
                    </CardContent>
                    <CardMedia>
                      <Image
                        alt="Object"
                        src={businessListImage}
                        width={186}
                        height={201}
                        style={{
                          objectFit: "cover",
                          border: "1px solid #ddd",
                          borderRadius: "7px",
                          padding: "3px",
                          ...(isSmallMobile && {
                            width: "100%",
                            height: "201px",
                          }),
                          ...(isTablets && {
                            width: "100%",
                            height: "201px",
                          }),
                          ...(isBiggerDevice && {
                            width: "170px",
                            height: "170px",
                          }),
                        }}
                      />
                    </CardMedia>
                  </Card>
                </Box>
                <Box
                  sx={{
                    width: "22%",
                    ...(isMobile && {
                      width: "100%",
                    }),
                  }}
                >
                  <Card
                    sx={{
                      background: "#7B8FD9",
                      padding: "11px 15px",
                      borderRadius: "10px",
                      ...(isSmallTabletss && {
                        minHeight: "398px",
                      }),
                      ...(isSmallTabletss && {
                        minHeight: "398px",
                      }),
                      ...(isBiggerDevice && {
                        padding: "5px 15px",
                        // minHeight:" 252px"
                      }),
                      ...(isSmallBiggerDevice && {
                        minHeight: "275px",
                      }),
                      ...(isSmallBiggersDevice && {
                        minHeight: "252px",
                      }),
                    }}
                  >
                    <Box sx={{ paddingX: "8px" }}>
                      <Typography
                        sx={{
                          marginY: "5px",
                          fontFamily: "Poppins",
                          fontSize: 20,
                          fontWeight: 600,

                          letterSpacing: "0.5px",
                          textAlign: "left",
                          color: "#FFFFFF",
                        }}
                      >
                        Recent Buy Leads
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Poppins",
                          fontSize: 14,
                          fontWeight: 600,

                          letterSpacing: "0px",
                          textAlign: "left",
                          color: "#FFFFFF",
                          marginBottom: "5px",
                        }}
                      >
                        Looking for Traders
                      </Typography>
                      <Divider sx={{ bgcolor: "white" }} />
                    </Box>
                    <Box>
                      <Carousel>
                        {loading ? (
                          <Box
                            sx={{
                              position: "absolute",
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              mx: "auto",
                            }}
                          >
                            <CircularProgress />
                          </Box>
                        ) : (
                          buyleads?.map((it: buyLeadsType) => (
                            <Box
                              key={it._id}
                              sx={{
                                paddingX: "10px",
                                display: "flex",
                                flexDirection: "column",
                              }}
                            >
                              <Typography
                                fontSize="12px"
                                color="white"
                                fontFamily="Poppins"
                                sx={{
                                  marginBottom: "5px",
                                  marginTop: "10px",
                                  fontWeight: "500",

                                  letterSpacing: "0em",
                                  textAlign: "left",
                                }}
                              >
                                {it.location && typeof it.location === "string"
                                  ? it.location
                                      .split(",")
                                      .map(
                                        (
                                          part: string,
                                          index: number,
                                          parts: string[]
                                        ) => {
                                          const trimmedPart = part.trim();

                                          if (index >= parts.length - 3) {
                                            if (index === parts.length - 3) {
                                              // Use a regex to remove "Division" from the part
                                              const withoutDivision =
                                                trimmedPart
                                                  .replace(/\bDivision\b/i, "")
                                                  .trim();
                                              const words =
                                                withoutDivision.split(" ");

                                              if (words.length === 2) {
                                                // Convert to uppercase and take the first word
                                                return (
                                                  <span key={index}>
                                                    {words[0].toUpperCase()}
                                                    {index < parts.length - 1
                                                      ? ", "
                                                      : ""}
                                                  </span>
                                                );
                                              } else {
                                                return (
                                                  <span key={index}>
                                                    {withoutDivision}
                                                    {index < parts.length - 1
                                                      ? ", "
                                                      : ""}
                                                  </span>
                                                );
                                              }
                                            }
                                            return (
                                              <span key={index}>
                                                {trimmedPart}
                                                {index < parts.length - 1
                                                  ? ", "
                                                  : ""}
                                              </span>
                                            );
                                          }

                                          return null;
                                        }
                                      )
                                  : null}
                              </Typography>
                              <Typography
                                variant="caption"
                                color="white"
                                fontFamily="Poppins"
                                sx={{
                                  display: "flex",
                                  flexDirection: "column",
                                }}
                              >
                                <Typography
                                  sx={{
                                    fontFamily: "Poppins",
                                    fontSize: 13,
                                    fontWeight: 600,

                                    letterSpacing: "0em",
                                    textAlign: "left",
                                    color: "#FFFFFF",
                                  }}
                                >
                                  Required Quantity : ₹ {it.requiredQuantity}
                                </Typography>
                                <Typography
                                  sx={{
                                    fontFamily: "Poppins",
                                    fontSize: 13,
                                    fontWeight: 600,

                                    letterSpacing: "0em",
                                    textAlign: "left",
                                    color: "#FFFFFF",
                                  }}
                                >
                                  Exprected Price: {it.expectedPrice}
                                </Typography>
                              </Typography>
                              <Typography
                                sx={{
                                  marginTop: "10px",
                                  fontFamily: "Poppins",
                                  fontSize: 12,
                                  fontWeight: 600,

                                  letterSpacing: "0em",
                                  textAlign: "left",
                                  color: "#FFFFFF",
                                }}
                              >
                                {formatCreatedAt(it.createdAt)}
                              </Typography>
                            </Box>
                          ))
                        )}
                      </Carousel>
                    </Box>
                  </Card>
                </Box>
              </Box>
            </Box>
          </Card>

          {/* Hero section ENDS */}

          {/* CATELOGUES section STARTING */}

          <Card
            sx={{
              padding: "30px",
              boxShadow: "none",
              borderRadius: "13px",
              marginTop: "20px",
              background: "#cfd8f95c",
            }}
          >
            <Box sx={{ width: "100%" }}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  paddingBottom: "18px",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Poppins",
                    fontSize: 20,
                    fontWeight: 600,
                    letterSpacing: "0.5px",
                    textAlign: "left",
                    color: "#2B305C",
                  }}
                >
                  Catalogues
                </Typography>
                <Link href="/catalogue" style={{ textDecoration: "auto" }}>
                  <Typography
                    sx={{
                      cursor: "pointer",
                      fontFamily: "Poppins",
                      fontSize: 16,
                      fontWeight: 600,

                      letterSpacing: "0em",
                      textAlign: "center",
                      color: "#2B376E",
                    }}
                  >
                    View All
                  </Typography>
                </Link>
              </Box>

              <Grid
                container
                spacing={{ xs: 2, md: 2 }}
                columns={{ xs: 4, sm: 8, md: 12 }}
              >
                {catalogueData
                  ?.map((_: catalogType, index: number) => (
                    <Grid
                      item
                      xs={10}
                      sm={4}
                      md={2}
                      key={index}
                      sx={{
                        cursor: "pointer",
                        paddingLeft: "14px !important",
                        paddingTop: "5px !important",
                        ...(isSmallMobile && {
                          width: "50%",
                          maxWidth: "50%",
                        }),
                        ...(isBigMobile && {
                          width: "50%",
                          maxWidth: "50%",
                        }),
                      }}
                    >
                      {
                        <Paper
                          elevation={1}
                          sx={{
                            backgroundColor: "white",
                            borderRadius: "7px",
                          }}
                        >
                          <Box
                            key={_._id}
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "flex-start",
                              paddingX: "10px",
                              paddingY: "10px",
                              color: "#FFFFFF",
                              marginY: "5px",
                           
                            }}
                            onClick={() => handleQuery(_._id)}
                          >
                            <Image
                              alt="image"
                              src={_.icon}
                              width={50}
                              height={50}
                              style={{
                                objectFit: "contain",
                                borderRadius: "40px",
                                background: "#f6f6f6",
                                padding: "3px",
                                border: "1px solid #f6f6f6",
                              }}
                            />
                            <Typography
                              noWrap
                              sx={{
                                display: "inline-block",
                                width: "59%",
                                fontFamily: "Poppins",
                                fontSize: "15px",
                                fontWeight: 500,
                                letterSpacing: "0em",
                                textAlign: "left",
                                color: "#333542",
                              }}
                            >
                              {_.name}
                            </Typography>
                          </Box>
                        </Paper>
                      }
                    </Grid>
                  ))
                  .slice(0, 12)}
              </Grid>
            </Box>
          </Card>

          {/* CATELOGUES section END */}
          {/* RECENTLY LISTED section START  */}
          <Card
            sx={{
              padding: "30px",
              boxShadow: "none",
              borderRadius: "13px",
              marginTop: "20px",
              background: "#fff",
              width: "100%",
            }}
          >
            <Box sx={{ width: "100%" }}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginY: "15px",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Poppins",
                    fontSize: 20,
                    fontWeight: 600,

                    letterSpacing: "0.5px",
                    textAlign: "left",
                    color: "#2B305C",
                  }}
                >
                  Recently Listed
                </Typography>
                <Typography
                  sx={{
                    cursor: "pointer",
                    fontFamily: "Poppins",
                    fontSize: 16,
                    fontWeight: 600,

                    letterSpacing: "0em",
                    textAlign: "center",
                    color: "#2B376E",
                  }}
                >
                  View All
                </Typography>
              </Box>

              <Grid
                container
                spacing={{ xs: 2, md: 2 }}
                columns={{ xs: 4, sm: 8, md: 12 }}
              >
                {loadingMarketPlace && (
                  // <Box
                  //   sx={{
                  //     position: "absolute",
                  //     display: "flex",
                  //     justifyContent: "center",
                  //     alignItems: "center",
                  //     // width:"90%",
                  //     // height:"20vh",
                  //     mx: "auto",
                  //   }}
                  // >
                  <Box sx={{ display: "flex", mx: "auto", marginY: "10px" }}>
                    <CircularProgress />
                  </Box>
                )}

                {marketPlace.map((_: any, index: any) => (
                  <Grid
                    item
                    xs={10}
                    sm={4}
                    md={3}
                    key={index}
                    sx={{
                      cursor: "pointer",
                    }}
                  >
                    {
                      <Card
                        sx={{
                          maxWidth: "345px",
                          background: "#f0f5f9",
                          borderRadius: "13px",
                          ...(isSmallMobile && {
                            width: "100%",
                            maxWidth: "100%",
                          }),
                          ...(isBigSmallMobile && {
                            width: "100%",
                            maxWidth: "100%",
                          }),
                        }}
                      >
                        <CardActionArea>
                          <CardMedia
                            component="img"
                            height="140px"
                            width="140px"
                            image={_.thumbnail}
                            alt={_.name}
                          />
                          <CardContent>
                            <Typography
                              gutterBottom
                              variant="h5"
                              component="div"
                            >
                              {_.name}
                            </Typography>
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                color: "#BFC8D6",
                                gap: "15px",
                              }}
                            >
                              {" "}
                              <VerticalShadesClosedOutlinedIcon />
                              <Typography
                                sx={{
                                  textAlign: "left",
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  fontWeight: 500,
                                  color: "#000",
                                  letterSpacing: "0em",
                                }}
                              >
                                {_.businessName}
                              </Typography>
                            </Box>
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                color: "#BFC8D6",
                                gap: "10px",
                              }}
                            >
                              <PlaceOutlinedIcon
                                sx={{
                                  width: "20px",
                                  height: "20px",
                                  color: "#BFC8D6",

                                  padding: "2.5px, 3.33px, 2.1px, 3.33px",
                                }}
                              />
                              <Typography
                                sx={{
                                  fontFamily: "Poppins",
                                  fontSize: 14,
                                  fontWeight: 500,
                                  color: "#333542",

                                  letterSpacing: "0em",
                                  textAlign: "left",
                                }}
                              >
                                {_.address
                                  .split(",")
                                  .map(
                                    (
                                      part: string,
                                      index: number,
                                      parts: string[]
                                    ) => {
                                      const trimmedPart = part.trim();

                                      if (index === parts.length - 3) {
                                        // Display the second-last part
                                        return (
                                          <span key={index}>
                                            {trimmedPart}
                                            {index < parts.length - 1
                                              ? ", "
                                              : ""}
                                          </span>
                                        );
                                      } else if (index === parts.length - 2) {
                                        // Display the third-last part
                                        return (
                                          <span key={index}>
                                            {trimmedPart}
                                            {index < parts.length - 1
                                              ? ", "
                                              : ""}
                                          </span>
                                        );
                                      }

                                      return null;
                                    }
                                  )}
                              </Typography>
                            </Box>
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                marginTop: "20px",
                              }}
                            >
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: "10px",
                                  padding: "3.5px, 7px, 3.5px, 7px",
                                  borderRadius: 25,
                                  backgroundColor: "#F7F7F7",
                                }}
                              >
                                <Box
                                  sx={{
                                    paddingX: "6px",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <StarBorderPurple500OutlinedIcon
                                    sx={{
                                      padding: "1.5px, 1.52px, 2.25px, 1.51px",
                                      color: "#FFBB3F",
                                    }}
                                  />
                                  <Typography
                                    sx={{
                                      fontFamily: "Poppins",
                                      fontSize: 12,
                                      fontWeight: 500,

                                      letterSpacing: "0em",
                                      textAlign: "left",
                                      color: "#333542",
                                    }}
                                  >
                                    {_.rating} Ratings
                                  </Typography>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  // width: 120,
                                  // height: 26,
                                  // top: 314,
                                  // left: 479,
                                  padding: "3.5px, 7px, 3.5px, 7px",
                                  borderRadius: 25,
                                  backgroundColor: "#F7F7F7",
                                }}
                              >
                                <Box
                                  sx={{
                                    paddingX: "6px",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "10px",
                                  }}
                                >
                                  <QuestionAnswerOutlinedIcon
                                    sx={{
                                      // width: 15,
                                      // height: 20,
                                      // top: 317,
                                      // left: 485.71,
                                      padding: "3.33px, 1.67px, 3.33px, 1.67px",
                                      Color: "#2B376E",
                                    }}
                                  />
                                  <Typography
                                    sx={{
                                      fontFamily: "Poppins",
                                      fontSize: 12,
                                      fontWeight: 500,

                                      letterSpacing: "0em",
                                      textAlign: "left",
                                      color: "#333542",
                                    }}
                                  >
                                    {_.enquires} Enquires
                                  </Typography>
                                </Box>
                              </Box>
                            </Box>
                          </CardContent>
                        </CardActionArea>
                        {/* <CardActions>
                  <Button size="small" color="primary" onClick={handleClickOpen2}>
                   Generate RFQs
                  </Button>
                </CardActions> */}
                      </Card>
                    }
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Card>
          {/* RECENTLY LISTED section END  */}
        </Grid>
      </Box>
    </PageContainer>
  );
};

export default Dashboard;
