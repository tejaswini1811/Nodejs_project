"use client";
import PageContainer from "@/app/(DashboardLayout)/components/container/PageContainer";
import DashboardCard from "@/app/(DashboardLayout)/components/shared/DashboardCard";
import {
  Divider,
  Stack,
  TextField,
  Theme,
  ThemeProvider,
  createTheme,
} from "@mui/material";
import { Box, CssBaseline, Grid, Typography, Button } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import { useEffect, useState } from "react";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import notfound from "@/img/notfound.png";
// import { rfqs } from "../../db";
import { usePathname } from "next/navigation";
import PlaceOutlinedIcon from "@mui/icons-material/PlaceOutlined";
import VerticalShadesClosedOutlinedIcon from "@mui/icons-material/VerticalShadesClosedOutlined";
import createAxiosInstance from "@/app/axiosInstance";
import toast from "react-hot-toast";
import Image from "next/image";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import { useAppselector } from "@/redux/store";
import Swal from "sweetalert2";

export default function Rfqs() {
  const [rfqData, setRfqData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [option, setOption] = useState<string>("sent");

  const pathname = usePathname();
  const { defaultBusinessId } = useAppselector((state) => state?.user.value);
  let businessId = defaultBusinessId;
  const handleChange = (event: SelectChangeEvent) => {
    setOption(event.target.value as string);
  };

  const fetchRfq = async () => {
    try {
      const axiosInstance = createAxiosInstance();

      const response = await axiosInstance.get(
        `rfq/list/${option}?businessId=${businessId}&pageNumber=1&count=12`
      );

      const newData = response.data.data;

      setRfqData(newData);

      setLoading(false);
    } catch (error: any) {
      toast.error(error?.response?.data?.message[0] || "An error occurred");
      setLoading(false);
    }
  };

  const deleteRfq = (id: string) => {
    try {
      const axiosInstance = createAxiosInstance();
      const response = axiosInstance.get(`rfq/cancel_rfq/${id}`);
      toast.success("rfq deleted successfully");
      fetchRfq();
    } catch (err) {
      console.log(err);
      toast.error("An error occurred");
    }
  };

  useEffect(() => {
    fetchRfq();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    fetchRfq();
    // eslint-disable-next-line
  }, [option]);

  const openCancleRfqSwal = (id: string) => {
    Swal.fire({
      title: "Cancle Rfq",
      text: "Do you want to cancle this RFQ",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result: any) => {
      if (result.isConfirmed) {
        deleteRfq(id);
      }
    });
  };

  const handleHover = {
    backgroundColor: "#2b305c",
    textDecoration: "underline",
  };

  return (
    <>
      <Grid container spacing={6} mb={2}>
        <Grid
          item
          xs={12}
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <h2 style={{ color: "#2B376E" }}> Home {pathname}</h2>

          <Stack spacing={1} direction={"row"}>
            <Box>
              <FormControl
                sx={{
                  width: 80,
                }}
                size="small"
              >
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={option}
                  defaultValue="Sent"
                  onChange={handleChange}
                >
                  <MenuItem value={"sent"}>Sent</MenuItem>
                  <MenuItem value={"received"}>Received</MenuItem>
                  <MenuItem value={"Cancelled"}>Cancelled</MenuItem>
                </Select>
              </FormControl>
            </Box>
            <Box>
              <TextField
                size="small"
                variant="outlined"
                placeholder="Products & Services"
                InputLabelProps={{
                  shrink: true,
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon
                        sx={{
                          width: 21,
                          height: 21,
                          padding: "2.83px, 2.84px, 2.84px, 2.83px",
                          color: "#BFC8D6",
                        }}
                      />
                    </InputAdornment>
                  ),
                  sx: {
                    borderRadius: "25px",
                    width: 255,
                    borderColor: "#CBD5E1",
                    backgroundColor: "#FFFFFF",
                  },
                }}
              />
            </Box>
          </Stack>
        </Grid>
      </Grid>
      <PageContainer>
        <DashboardCard>
          <Grid
            container
            spacing={2}
            sx={{
              height: "auto",
              overflow: "auto",
              paddingBottom: "5px",
              margin: "0",
              paddinLeft: "0px",
            }}
          >
            <Box
              sx={{
                position: "absolute",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                // height: "70vh",
                mx: "auto",
              }}
            ></Box>
            {rfqData.length > 0 ? (
              rfqData.map((item: any, index: number) => (
                <div key={index} style={{ width: "23%", marginRight: "16px" }}>
                  <Box key={item._id}>
                    <Card
                      sx={{
                        width: "100%",
                        background: "#f0f5f9",
                        marginBottom: "16px",
                      }}
                    >
                      <CardContent sx={{ minHeight: "225px" }}>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                          }}
                        >
                          <Typography
                            sx={{
                              fontFamily: "Poppins",
                              fontSize: "16px",
                              fontWeight: 500,
                              letterSpacing: "0em",
                              textAlign: "left",
                              color: "#000000",
                            }}
                          >
                            {item.productName}
                          </Typography>
                          <Typography
                            sx={{
                              fontFamily: "Poppins",
                              fontSize: "16px",
                              fontWeight: 700,
                              letterSpacing: "0em",
                              textAlign: "left",
                              color: "darkblue",
                            }}
                          >
                            {item?.RFQUniqueId}
                          </Typography>
                          <Typography
                            sx={{
                              fontFamily: "Poppins",
                              fontSize: "12px",
                              fontWeight: 600,
                              letterSpacing: "0em",
                              textAlign: "left",
                              color: "#2B376E",
                            }}
                          >
                            {item.address && typeof item.address === "string"
                              ? item.address
                                  .split(",")
                                  .map(
                                    (
                                      part: string,
                                      index: number,
                                      parts: string[]
                                    ) => {
                                      const trimmedPart = part.trim();

                                      if (index >= parts.length - 3) {
                                        if (index === parts.length - 3) {
                                          // Use a regex to remove "Division" from the part
                                          const withoutDivision = trimmedPart
                                            .replace(/\bDivision\b/i, "")
                                            .trim();
                                          const words =
                                            withoutDivision.split(" ");

                                          if (words.length === 2) {
                                            // Convert to uppercase and take the first word
                                            return (
                                              <span key={index}>
                                                {words[0].toUpperCase()}
                                                {index < parts.length - 1
                                                  ? ", "
                                                  : ""}
                                              </span>
                                            );
                                          } else {
                                            return (
                                              <span key={index}>
                                                {withoutDivision}
                                                {index < parts.length - 1
                                                  ? ", "
                                                  : ""}
                                              </span>
                                            );
                                          }
                                        }
                                        return (
                                          <span key={index}>
                                            {trimmedPart}
                                            {index < parts.length - 1
                                              ? ", "
                                              : ""}
                                          </span>
                                        );
                                      }

                                      return null;
                                    }
                                  )
                              : null}
                          </Typography>
                        </Box>
                        <Box
                          sx={{
                            display: "flex",
                            gap: "3px",
                            marginY: "10px",
                            alignItems: "flex-start",
                          }}
                        >
                          <VerticalShadesClosedOutlinedIcon
                            sx={{
                              width: "31px",
                              height: "31px",
                              color: "#fff",
                              padding: "6px",
                              borderRadius: "23px",
                              background: "#5c934c",
                            }}
                          />
                          <Typography
                            sx={{
                              fontFamily: "Poppins",
                              fontSize: "14px",
                              fontWeight: 500,
                              letterSpacing: "0em",
                              textAlign: "left",
                              color: "#000000",
                            }}
                          >
                            {item.companyName}
                          </Typography>
                        </Box>
                        <Grid container spacing={0}>
                          <Grid item xs={6} sx={{ textAlign: "left" }}>
                            <Typography
                              sx={{
                                fontFamily: "Poppins",
                                fontSize: "14px",
                                fontWeight: 600,

                                letterSpacing: "0em",
                                textAlign: "left",
                                color: "#333542",
                                marginBottom: "1px",
                              }}
                            >
                              Expected Price{" "}
                            </Typography>

                            <Typography
                              sx={{
                                fontFamily: "Poppins",
                                fontSize: "13px",
                                fontWeight: 500,
                                letterSpacing: "0em",
                                textAlign: "left",
                                color: "#000000",
                                marginBottom: "1px",
                              }}
                            >
                              {" "}
                              {item.expectedPrice}
                            </Typography>
                          </Grid>
                          <Grid item xs={6} sx={{ textAlign: "left" }}>
                            <Typography
                              sx={{
                                fontFamily: "Poppins",
                                fontSize: "14px",
                                fontWeight: 600,

                                letterSpacing: "0em",
                                textAlign: "left",
                                color: "#333542",
                                marginBottom: "1px",
                              }}
                            >
                              Required Quantity{" "}
                            </Typography>

                            <Typography
                              sx={{
                                fontFamily: "Poppins",
                                fontSize: 14,
                                fontWeight: 500,

                                letterSpacing: "0em",
                                textAlign: "left",
                                color: "#333542",

                                marginBottom: "1px",
                              }}
                            >
                              {" "}
                              {/* 1 sq.cm */}
                              {item.requiredQuantity}
                            </Typography>
                          </Grid>
                        </Grid>
                        <Typography
                          sx={{
                            fontFamily: "Poppins",
                            fontSize: 14,
                            fontWeight: 500,
                            letterSpacing: "0em",
                            color: "#333542",
                            marginTop: "10px",
                            marginBottom: "1px",
                          }}
                        >
                          {" "}
                          {/* 1 sq.cm */}
                          <span style={{ color: "orange", fontSize: "12px" }}>
                            Date:{" "}
                          </span>{" "}
                          {item.createdAt}
                        </Typography>
                      </CardContent>
                      <CardActions sx={{ padding: "0px" }}>
                        <Button
                          size="small"
                          onClick={() => openCancleRfqSwal(item.rfqId)}
                          sx={{
                            padding: "8px",
                            background: "#2b305c",
                            width: "100%",
                            textAlign: "center",
                            color: "#fff",
                            borderRadius: "0px",
                            "&:hover": handleHover,
                          }}
                        >
                          Cancel
                        </Button>
                      </CardActions>
                    </Card>
                  </Box>
                </div>
              ))
            ) : (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  mx: "auto",
                }}
              >
                <Image src={notfound} alt="Not Found" />
              </Box>
            )}
          </Grid>
        </DashboardCard>
      </PageContainer>
    </>
  );
}
